#include "commonheaders.h"

void dndInit();
int updateGlobal(int status);
int updateSelective(char uid[], int status);
int connectuser(char f_uid[], char t_uid[]);