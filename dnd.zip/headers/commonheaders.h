#if !defined(HEADERS)
#define HEADERS -1

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <assert.h>
#include <locale.h>
#include <sys/time.h>

#endif // HEADERS
