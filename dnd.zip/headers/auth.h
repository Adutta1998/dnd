#include "commonheaders.h"

int registeruser(char name[], char mob[], char password[]);
int loginuser(char uid[], char password[]);